﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Quartz;
using QuartzTest1.Jobs;
using QuartzTest1.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace QuartzTest1.Controllers
{
    public class HomeController : Controller
    {
        /* private readonly ILogger<HomeController> _logger;*/

        /*  public HomeController(ILogger<HomeController> logger)
          {
              _logger = logger;
          }*/
        IScheduler _scheduler;
        public HomeController(IScheduler scheduler)
        {
            _scheduler = scheduler;
        }

        public IActionResult Index()
        {
            return View();
        }

        public async Task<IActionResult> StartSimpleJob()
        {
            //trigger our simple job
            
            IJobDetail job = JobBuilder.Create<SimpleJob>()
                .WithIdentity("simplejob", "quartzexample")
                .UsingJobData("username","Ahmed")
                .UsingJobData("password","security!!")
                .StoreDurably()
                .Build();

            job.JobDataMap.Put("user", new JobUserParameter { Username = "Ahmed", Password = "security!!" });

            // save the job

            await _scheduler.AddJob(job, true);


            ITrigger trigger = TriggerBuilder.Create()
                .ForJob(job)
                .UsingJobData("triggerparam","Simple trigger 1 Parameter")
                .WithIdentity("testtriger", "quartzexample")
                .StartNow()
                .WithSimpleSchedule(x => x.WithIntervalInSeconds(5).WithRepeatCount(5))
                .Build();

            await _scheduler.ScheduleJob(trigger);

            // second trigger for the same job ( multiple trigger )

            ITrigger trigger2 = TriggerBuilder.Create()
               .ForJob(job)
               .UsingJobData("triggerparam", "Simple trigger 2 Parameter")
               .WithIdentity("testtriger2", "quartzexample")
               .StartNow()
               .WithSimpleSchedule(x => x.WithIntervalInSeconds(5).WithRepeatCount(5))
               .Build();

            await _scheduler.ScheduleJob(trigger2);


            return RedirectToAction("Index");
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
